### How to run ->

- #### cd AtEM
- #### npm install
- #### cd client
- #### npm install
- #### cd ..
- #### npm run dev